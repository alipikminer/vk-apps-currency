self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6350df0eb1d0cfd535bf24060d910561",
    "url": "/vk-apps-currency/index.html"
  },
  {
    "revision": "0844e676a1fee0a56b26",
    "url": "/vk-apps-currency/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "58690252bc075a46dcf5",
    "url": "/vk-apps-currency/static/css/main.3ac9ad7d.chunk.css"
  },
  {
    "revision": "0844e676a1fee0a56b26",
    "url": "/vk-apps-currency/static/js/2.07924208.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/vk-apps-currency/static/js/2.07924208.chunk.js.LICENSE.txt"
  },
  {
    "revision": "58690252bc075a46dcf5",
    "url": "/vk-apps-currency/static/js/main.752c4580.chunk.js"
  },
  {
    "revision": "74e5bbde9c7dc0f59f0a",
    "url": "/vk-apps-currency/static/js/runtime-main.c4deca24.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/vk-apps-currency/static/media/persik.4e1ec840.png"
  }
]);